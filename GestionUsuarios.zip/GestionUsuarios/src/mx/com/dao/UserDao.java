package mx.com.dao;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import mx.com.domain.User;

public class UserDao implements Dao<User> {
    private Connection conexion;

    public UserDao(Connection conexion) {
        this.conexion = conexion;
    }

    @Override
    public List getAll() {
        List<User> users = new ArrayList<>();
        String query = "SELECT * FROM usuario";

        try (PreparedStatement stmt = conexion.prepareStatement(query); ResultSet resultSet = stmt.executeQuery()) {
            while (resultSet.next()) {
                User user = new User();
                
                user.setLogin(resultSet.getString("login"));
                user.setPassword(resultSet.getString("password"));
                user.setNombre(resultSet.getString("nombre"));
                user.setCliente(resultSet.getFloat("cliente"));
                user.setEmail(resultSet.getString("email"));
                user.setFechaAlta(resultSet.getString("fecha_alta"));
                user.setFechaBaja(resultSet.getString("fecha_baja"));
                user.setStatus(resultSet.getString("status").charAt(0));
                user.setIntentos(resultSet.getFloat("intentos"));
                user.setFechaRevocado(resultSet.getString("fecha_revocado"));
                user.setFechaVigencia(resultSet.getString("fecha_vigencia"));
                user.setNoAcceso(resultSet.getInt("no_acceso"));
                user.setApellidoPaterno(resultSet.getString("apellido_paterno"));
                user.setApellidoMaterno(resultSet.getString("apellido_materno"));
                user.setArea(resultSet.getInt("area"));
                user.setFechaModificacion(resultSet.getString("fecha_modificacion"));

                users.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }

    @Override
    public void create(User user) {
        String query = "INSERT INTO usuario (login, password, nombre, cliente, email, fecha_alta, fecha_baja, status, intentos, fecha_revocado, fecha_vigencia, no_acceso, apellido_paterno, apellido_materno, area, fecha_modificacion) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conexion.prepareStatement(query)) {
            String password = user.getPassword();
            
            // Calcula el hash SHA-256
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedPassword = md.digest(password.getBytes());

            // Codifica el hash en Base64
            String hashedPasswordBase64 = Base64.getEncoder().encodeToString(hashedPassword);

            stmt.setString(1, user.getLogin());
            stmt.setString(2, hashedPasswordBase64);
            stmt.setString(3, user.getNombre());
            stmt.setFloat(4, user.getCliente());
            stmt.setString(5, user.getEmail());
            stmt.setString(6, user.getFechaAlta());
            stmt.setString(7, user.getFechaBaja());
            stmt.setString(8, String.valueOf(user.getStatus()));
            stmt.setFloat(9, user.getIntentos());
            stmt.setString(10, user.getFechaRevocado());
            stmt.setString(11, user.getFechaVigencia());
            stmt.setInt(12, user.getNoAcceso());
            stmt.setString(13, user.getApellidoPaterno());
            stmt.setString(14, user.getApellidoMaterno());
            stmt.setInt(15, user.getArea());
            stmt.setString(16, user.getFechaModificacion());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public User read(String login) {
        String query = "SELECT * FROM usuario WHERE login = ?";
        User user = new User();

        try (PreparedStatement stmt = conexion.prepareStatement(query)) {
            stmt.setString(1, login);

            try (ResultSet resultSet = stmt.executeQuery()) {
                if (resultSet.next()) {
                    user.setLogin(resultSet.getString("login"));
                    user.setPassword(resultSet.getString("password"));
                    user.setNombre(resultSet.getString("nombre"));
                    user.setCliente(resultSet.getFloat("cliente"));
                    user.setEmail(resultSet.getString("email"));
                    user.setFechaAlta(resultSet.getString("fecha_alta"));
                    user.setFechaBaja(resultSet.getString("fecha_baja"));
                    user.setStatus(resultSet.getString("status").charAt(0));
                    user.setIntentos(resultSet.getFloat("intentos"));
                    user.setFechaRevocado(resultSet.getString("fecha_revocado"));
                    user.setFechaVigencia(resultSet.getString("fecha_vigencia"));
                    user.setNoAcceso(resultSet.getInt("no_acceso"));
                    user.setApellidoPaterno(resultSet.getString("apellido_paterno"));
                    user.setApellidoMaterno(resultSet.getString("apellido_materno"));
                    user.setArea(resultSet.getInt("area"));
                    user.setFechaModificacion(resultSet.getString("fecha_modificacion"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return user;
    }

    @Override
    public void update(User user) {
        String query = "UPDATE usuario SET nombre = ?, cliente = ?, email = ?, fecha_alta = ?, fecha_baja = ?, status = ?, intentos = ?, fecha_revocado = ?, fecha_vigencia = ?, no_acceso = ?, apellido_paterno = ?, apellido_materno = ?, area = ?, fecha_modificacion = ? ";
        String hashedPasswordBase64 = "";
        
        if (!user.getPassword().isEmpty()) {
            hashedPasswordBase64 = shaEncriptPassword(user.getPassword());    
            query += ", password = ? ";
        }
        
        query += "WHERE login = ?";
        
        try (PreparedStatement stmt = conexion.prepareStatement(query)) {
            stmt.setString(1, user.getNombre());
            stmt.setFloat(2, user.getCliente());
            stmt.setString(3, user.getEmail());
            stmt.setString(4, user.getFechaAlta());
            stmt.setString(5, user.getFechaBaja());
            stmt.setString(6, String.valueOf(user.getStatus()));
            stmt.setFloat(7, user.getIntentos());
            stmt.setString(8, user.getFechaRevocado());
            stmt.setString(9, user.getFechaVigencia());
            stmt.setInt(10, user.getNoAcceso());
            stmt.setString(11, user.getApellidoPaterno());
            stmt.setString(12, user.getApellidoMaterno());
            stmt.setInt(13, user.getArea());
            stmt.setString(14, user.getFechaModificacion());
            
            if (!user.getPassword().isEmpty()){ 
                stmt.setString(15, hashedPasswordBase64);
                stmt.setString(16, user.getLogin());
            } else {
                stmt.setString(15, user.getLogin());
            }

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(String login) {
        String query = "DELETE FROM usuario WHERE login = ?";

        try (PreparedStatement stmt = conexion.prepareStatement(query)) {
            stmt.setString(1, login);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public List getAllByStatus(char status) {
        List<User> users = new ArrayList<>();
        String query = "SELECT * FROM usuario WHERE status = '" + status + "'";

        try (PreparedStatement stmt = conexion.prepareStatement(query); ResultSet resultSet = stmt.executeQuery()) {
            while (resultSet.next()) {
                User user = new User();
                
                user.setLogin(resultSet.getString("login"));
                user.setPassword(resultSet.getString("password"));
                user.setNombre(resultSet.getString("nombre"));
                user.setCliente(resultSet.getFloat("cliente"));
                user.setEmail(resultSet.getString("email"));
                user.setFechaAlta(resultSet.getString("fecha_alta"));
                user.setFechaBaja(resultSet.getString("fecha_baja"));
                user.setStatus(resultSet.getString("status").charAt(0));
                user.setIntentos(resultSet.getFloat("intentos"));
                user.setFechaRevocado(resultSet.getString("fecha_revocado"));
                user.setFechaVigencia(resultSet.getString("fecha_vigencia"));
                user.setNoAcceso(resultSet.getInt("no_acceso"));
                user.setApellidoPaterno(resultSet.getString("apellido_paterno"));
                user.setApellidoMaterno(resultSet.getString("apellido_materno"));
                user.setArea(resultSet.getInt("area"));
                user.setFechaModificacion(resultSet.getString("fecha_modificacion"));

                users.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }
    
    public List getAllByFields(String name, String registrationDate, String cancellationDate) {
        List<User> users = new ArrayList<>();
        String query = "SELECT * FROM usuario ";
        
        if (!name.isEmpty() && !registrationDate.isEmpty() && !cancellationDate.isEmpty()) {
            query += "WHERE nombre LIKE '%" + name + "%' AND fecha_alta LIKE '%" + registrationDate + "%' AND fecha_baja LIKE '%" + cancellationDate + "%'";
        } else if (!name.isEmpty() && !registrationDate.isEmpty()) {
            query += "WHERE nombre LIKE '%" + name + "%' AND fecha_alta LIKE '%" + registrationDate + "%'";
        } else if (!name.isEmpty() && !cancellationDate.isEmpty()) {
            query += "WHERE nombre LIKE '%" + name + "%' AND fecha_baja LIKE '%" + cancellationDate + "%'";
        } else if (!registrationDate.isEmpty() && !cancellationDate.isEmpty()) {
            query += "WHERE fecha_alta LIKE '%" + registrationDate + "%' AND fecha_baja LIKE '%" + cancellationDate + "%'";
        } else if (!name.isEmpty()) {
            query += "WHERE nombre LIKE '%" + name + "%'";
        } else if (!registrationDate.isEmpty()){
            query += "WHERE fecha_alta LIKE '%" + registrationDate + "%'";
        } else if (!cancellationDate.isEmpty()) {
            query += "WHERE fecha_baja LIKE '%" + cancellationDate + "%'";
        }

        try (PreparedStatement stmt = conexion.prepareStatement(query); ResultSet resultSet = stmt.executeQuery()) {
            while (resultSet.next()) {
                User user = new User();
                
                user.setLogin(resultSet.getString("login"));
                user.setPassword(resultSet.getString("password"));
                user.setNombre(resultSet.getString("nombre"));
                user.setCliente(resultSet.getFloat("cliente"));
                user.setEmail(resultSet.getString("email"));
                user.setFechaAlta(resultSet.getString("fecha_alta"));
                user.setFechaBaja(resultSet.getString("fecha_baja"));
                user.setStatus(resultSet.getString("status").charAt(0));
                user.setIntentos(resultSet.getFloat("intentos"));
                user.setFechaRevocado(resultSet.getString("fecha_revocado"));
                user.setFechaVigencia(resultSet.getString("fecha_vigencia"));
                user.setNoAcceso(resultSet.getInt("no_acceso"));
                user.setApellidoPaterno(resultSet.getString("apellido_paterno"));
                user.setApellidoMaterno(resultSet.getString("apellido_materno"));
                user.setArea(resultSet.getInt("area"));
                user.setFechaModificacion(resultSet.getString("fecha_modificacion"));

                users.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }
    
    private String shaEncriptPassword(String password) {
        String hashedPasswordBase64 = "";

        try {
            // Calcula el hash SHA-256
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedPassword = md.digest(password.getBytes());

            // Codifica el hash en Base64
            hashedPasswordBase64 = Base64.getEncoder().encodeToString(hashedPassword);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        }

        return hashedPasswordBase64;
    }
       
}
