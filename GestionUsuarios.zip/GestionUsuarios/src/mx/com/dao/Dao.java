package mx.com.dao;

import java.util.List;

public interface Dao<T> {
    List<T> getAll();
    
    void create(T entity);
    
    T read(String login);
    
    void update(T entity);
    
    void delete(String login);
}
