package mx.com.auth;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;
import mx.com.dao.UserDao;

public class Auth {
    private Connection conexion;

    public Auth(Connection conexion) {
        this.conexion = conexion;
    }

    public boolean login(String login, String password) {
        String query = "SELECT * FROM usuario WHERE login = ? AND password = ? AND (fecha_vigencia >= ? OR fecha_vigencia IS NULL)";
        boolean isLogin = false;

        try (PreparedStatement stmt = conexion.prepareStatement(query)) {
            // Obtener la fecha actual
            LocalDate currentDate = LocalDate.now();

            // Formatear la fecha en el formato deseado
            DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            String currentDateFormatter = currentDate.format(format);
        
            stmt.setString(1, login);
            stmt.setString(2, shaEncriptPassword(password));
            stmt.setString(3, currentDateFormatter);

            try (ResultSet resultSet = stmt.executeQuery()) {
                if (resultSet.next()) {
                    isLogin = true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return isLogin;
    }
    
    private String shaEncriptPassword(String password) {
        String hashedPasswordBase64 = "";

        try {
            // Calcula el hash SHA-256
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedPassword = md.digest(password.getBytes());

            // Codifica el hash en Base64
            hashedPasswordBase64 = Base64.getEncoder().encodeToString(hashedPassword);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        }

        return hashedPasswordBase64;
    }

}
