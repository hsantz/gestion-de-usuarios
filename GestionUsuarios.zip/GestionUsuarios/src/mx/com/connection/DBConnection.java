package mx.com.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    // Conecta a la base de datos
    private String urlDB = "jdbc:mysql://localhost:3306/gestion_usuarios";
    private String userDB = "root";
    private String passwordDB = "admin";
    private Connection connection;

    public Connection openConnection() {
        try {
            // Cargamos el driver de MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Establecemos la conexión
            connection = DriverManager.getConnection(urlDB, userDB, passwordDB);
            
            System.out.println("Conexión a la base de datos establecida.");
        } catch (ClassNotFoundException e) {
            System.err.println("Error: No se encontró el driver de MySQL.");
        } catch (SQLException e) {
            System.err.println("Error: No se pudo conectar a la base de datos.");
        }
        
        return connection;
    }

    public void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Conexión a la base de datos cerrada.");
            } catch (SQLException e) {
                System.err.println("Error al cerrar la conexión a la base de datos.");
            }
        }
    }
}

