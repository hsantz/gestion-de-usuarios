package mx.com.domain;

public class User {
    private String login;
    private String password;
    private String nombre;
    private float cliente;
    private String email;
    private String fechaAlta;
    private String fechaBaja;
    private char status;
    private float intentos;
    private String fechaRevocado;
    private String fechaVigencia;
    private int noAcceso;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private int area;
    private String fechaModificacion;

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getCliente() {
        return cliente;
    }

    public void setCliente(float cliente) {
        this.cliente = cliente;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(String fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public String getFechaBaja() {
        return fechaBaja;
    }

    public void setFechaBaja(String fechaBaja) {
        this.fechaBaja = fechaBaja;
    }

    public char getStatus() {
        return status;
    }

    public void setStatus(char status) {
        this.status = status;
    }

    public float getIntentos() {
        return intentos;
    }

    public void setIntentos(float intentos) {
        this.intentos = intentos;
    }

    public String getFechaRevocado() {
        return fechaRevocado;
    }

    public void setFechaRevocado(String fechaRevocado) {
        this.fechaRevocado = fechaRevocado;
    }

    public String getFechaVigencia() {
        return fechaVigencia;
    }

    public void setFechaVigencia(String fechaVigencia) {
        this.fechaVigencia = fechaVigencia;
    }

    public int getNoAcceso() {
        return noAcceso;
    }

    public void setNoAcceso(int noAcceso) {
        this.noAcceso = noAcceso;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public int getArea() {
        return area;
    }

    public void setArea(int area) {
        this.area = area;
    }

    public String getFechaModificacion() {
        return fechaModificacion;
    }

    public void setFechaModificacion(String fechaModificacion) {
        this.fechaModificacion = fechaModificacion;
    }

}

